Compose Desktop Application

- `./gradlew run` - run application
- `./gradlew package` - package native distribution into `build/compose/binaries`
